def main():
    print("Hello Man")
